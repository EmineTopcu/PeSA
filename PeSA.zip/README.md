# PeSA
**Pe**ptide **S**pecificity **A**nalysis

PeSA is an open source software designed as a tool to use in analysis of peptide arrays, permutation arrays and OPALs. 
Analysis can be used to generate motifs to share the results as a position-specific scoring matrix (PSSM).
